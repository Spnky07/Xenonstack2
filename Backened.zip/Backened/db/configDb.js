const mongoose=require("mongoose");
const connectDB=async(req,res)=>{
    try{
        await mongoose.connect("mongodb://127.0.0.1:27017/CS&P");
        console.log("connected success");
    }catch(err){
        console.log(err);
        return res.status(500).json({
            message:'error in connection',
            success:false
        })
    }
}
module.exports=connectDB;