const mongoose=require("mongoose");

const mongooseSchema=new mongoose.Schema({
    name:{
        type:String,
        required:true
    },
    mobileNo:{
        type:Number,
        required:true
    },
    altmobileNo:{
        type:Number,
        required:true
    },
    work:{
        type:String,
        required:true
    },
    place:{
        type:String,
        required:true
    }
})
const service=mongoose.model('service',mongooseSchema);
module.exports=service;