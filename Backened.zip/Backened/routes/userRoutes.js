const express=require("express");
const {RegisterController, loginController, addServiceProvider} = require("../controller/userController");

const router=express.Router();

router.post('/register',RegisterController);
router.post('/login',loginController);

router.post('/add-serviceProvider',addServiceProvider);

module.exports=router;