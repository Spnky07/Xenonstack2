const express=require("express");

const app=express();

const connect=require("./db/configDb");
connect();

app.use(express.json());
app.use(express.urlencoded());

const dotenv=require("dotenv");
dotenv.config();

app.get('/',(req,res)=>{
    res.send("<h1>Hello</h1>")
})


app.use('/api/v1/user',require("./routes/userRoutes"));
const PORT=process.env.PORT;

app.listen(PORT,(req,res)=>{
    console.log('server is listening');
})